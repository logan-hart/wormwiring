function S = weightSim(x,y)

C1 = .5;
C2 = 1;

% S = -max(x,y).*exp(-min(x,y)) + min(x,y) .* exp(-abs(x-y)./(x+y));
S = (-1 * C1) .* max(x,y).*exp((-1 * C2) .*min(x,y)) + min(x,y);

S(isnan(S)) = 0;

end

