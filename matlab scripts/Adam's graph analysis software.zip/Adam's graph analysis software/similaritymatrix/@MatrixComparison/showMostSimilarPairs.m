function showMostSimilarPairs(obj,N)
%UNTITLED13 Summary of this function goes here
%   Detailed explanation goes here


[vals idxs] = sort(obj.S(:),'descend');

fprintf('%-20s%-20sSimilarity\n',obj.name1,obj.name2);
for i = 1:N
    [j k] = ind2sub(size(obj.S),idxs(i));
    fprintf('%-20s%-20s%.3f\n',obj.SrowLabels{j},obj.ScolumnLabels{k},obj.S(j,k));
end


end

