function sameNodeSimilarity(obj)
%UNTITLED15 Summary of this function goes here
%   Detailed explanation goes here

vals = [];
for i = 1:numel(obj.SrowLabels)
    j = find(strcmp(obj.ScolumnLabels,obj.SrowLabels{i}));
    vals = [vals ; obj.S(i,j)];
end

[sortedVals idxs] = sort(vals,'descend');

for i = 1:numel(sortedVals)
    
    fprintf('%-20s%-20s%.4f\n',obj.SrowLabels{idxs(i)},obj.SrowLabels{idxs(i)},sortedVals(i));
end



end

