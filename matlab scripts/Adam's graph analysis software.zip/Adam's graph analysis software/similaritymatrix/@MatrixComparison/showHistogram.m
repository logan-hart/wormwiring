function showHistogram(obj,N)
%UNTITLED14 Summary of this function goes here
%   Detailed explanation goes here

hist(obj.S(:),N);
title('Distribution of values in comparison matrix');
xlabel('Similarity value for pair');
ylabel('Number of pairs');
end

