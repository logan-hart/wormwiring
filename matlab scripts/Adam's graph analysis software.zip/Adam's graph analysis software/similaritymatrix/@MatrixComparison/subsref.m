function val = subsref(A,S)
%UNTITLED18 Summary of this function goes here
%   Detailed explanation goes here

switch S.type
    case '()'
        if numel(S.subs) ~= 2
            error('MatrixComparison:Subsetting','Subsetting matrix comparison requires two arguments');
        end
        rowNumber = find(strcmp(A.SrowLabels,S.subs{1}));
        columnNumber = find(strcmp(A.ScolumnLabels,S.subs{2}));
        if isempty(rowNumber)
            error('MatrixComparison:Subsetting',sprintf('Could not find neuron %s',S.subs{1}));
        end
        if isempty(columnNumber)
            error('MatrixComparison:Subsetting',sprintf('Could not find neuron %s',S.subs{2}));
        end
        
        val = A.S(rowNumber,columnNumber);
end

        
end

