function h = showHistogram(obj,N)

% Form histogram
tmp = triu(obj.S,1);
tmp(logical(tril(ones(size(tmp)),0))) = -Inf;
hist(tmp(~isinf(tmp)),N); title('Histogram of similarity values');

% [L x] = hist(tmp(~isinf(tmp)),N);

h = gca;
end

