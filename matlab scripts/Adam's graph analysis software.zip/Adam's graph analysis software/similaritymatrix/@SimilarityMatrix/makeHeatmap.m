function H = makeHeatmap(obj,labels)
%UNTITLED6 Summary of this function goes here
%   Detailed explanation goes here

[I IA IB] = intersect(obj.Slabels,labels);


obj.Slabels(IA)
H = HeatMap(obj.S(IA,IA),'RowLabels',obj.Slabels(IA),'ColumnLabels',obj.Slabels(IA), 'ColorMap',hot,'Symmetric',false);



end

