function makeDendrogram(obj,labels)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
if nargin == 1
    labels = {};
end


if numel(labels)>0
    [C,IA,IB] = INTERSECT(obj.Slabels,labels);
%     IA;
    M = createDistMat(1-obj.S(IA,IA));
else
    M = createDistMat(1-obj.S);
    labels = obj.Slabels;
end

dendrogram(linkage(full(M)),0,'labels',labels,'orient','left');

    function M = createDistMat(S)
        M = [];
        for kk = 1:(size(S,2)-1)
            M = [M S((kk+1):size(S,1),kk)'];
        end
    end


end

