function iterWeightSimilarity(obj,varargin)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

javaaddpath('C:\Users\Scott\Desktop\Adam\NetBeans Projects\IterWeightSimilarity\build\classes');

[A labels] = getSquareMatrix(obj.adjMat);
S = eye(size(A));
nIters = 10;
for i = 1:nIters
    % Call external Java implementation (necessary to perform this
    % intensive computation)
    S2 = IterWeightSimilarity.IterWeightSimilarity.updateWeight(S,A);
    disp(norm(S-S2,'fro'));
    
    S = S2;
end

obj.S = S;
obj.Slabels = labels;

showHistogram(obj,50);

javarmpath('C:\Users\Scott\Desktop\Adam\NetBeans Projects\IterWeightSimilarity\build\classes');

end

