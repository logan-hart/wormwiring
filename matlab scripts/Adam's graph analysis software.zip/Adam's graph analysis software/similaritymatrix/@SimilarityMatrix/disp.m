function disp(obj)
%DISP Display information for a SimilarityMatrix object


fprintf('SimilarityMatrix object\nSimilarityMethod: %s\n',obj.similarityMethod);
fprintf('%u nodes in network\n', size(obj.S,1));


end

