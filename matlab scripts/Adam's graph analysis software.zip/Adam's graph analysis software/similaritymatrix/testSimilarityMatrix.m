A2 = sparse(9,9);
A2(1,2) = 5;
A2(1,3) = 5;
A2(1,4) = 5;
A2(1,5) = 3;
A2(5,1) = 10;
A2(5,6) = 10;
A2(6,5) = 3;
A2(6,7) = 5;
A2(6,8) = 5;
A2(6,9) = 5;
A2 = double(A2>0);
labels = {};
for i = 1:12, labels{i} = num2str(i); end

testAdjMat2 = AdjacencyMatrix(A2,labels(1:9),labels(1:9),'test matrix');
testSimTan = SimilarityMatrix(testAdjMat2,'similarityMethod','tanimoto','direction','outgoing');


% testSim = SimilarityMatrix(testAdjMat2,'similarityMethod','iterWeightSimilarity');
% testSim2 = SimilarityMatrix(testAdjMat2,'similarityMethod','weightSimilarity');


% makeDendrogram(testSim)
% generateSimilarityDendrogram(A2,labels(1:9));

clear A2 labels testAdjMat2