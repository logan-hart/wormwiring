function S = updateSimRank(A,S,outWeight,inWeight,outMat,inMat)

Sout = outWeight*(A*S*A')./outMat; Sout(isnan(Sout)) = 0;
Sin = inWeight*(A'*S*A)./inMat; Sin(isnan(Sin)) = 0;
S = .5*(Sout + Sin);

end

