N = 50;
Qs = zeros(1,N);
for i = 1:N
    tmpMat = threshold(chemMaleOnlyGrped,i);
    [commLabs Qs(i)] = getCommunitiesMM(tmpMat,'quiet');
end

plot(1:N,Qs);
title('Maximum modularity vs. threshold level, chemical matrix')
set(gcf,'color',[1 1 1]);