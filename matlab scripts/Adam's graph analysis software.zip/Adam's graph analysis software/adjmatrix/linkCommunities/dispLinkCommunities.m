function dispLinkCommunities(array)
N  = 0;
for i = 1:numel(array)
    if numel(array{i}) > 2
        for j = 1:(numel(array{i})-1)
            fprintf('%s, ',array{i}{j})
        end
        fprintf('%s\n',array{i}{j+1});
    N = N+1;
    end
end
fprintf('%u non-trivial communities\n',N);
end
