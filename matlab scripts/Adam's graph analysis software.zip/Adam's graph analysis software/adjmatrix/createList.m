function list = createList(labelsArray,indent)

list = {};
for i = 1:numel(labelsArray)
    switch class(labelsArray{i})
        case 'cell'
%             fprintf('\n\n');
            list = [list createList(labelsArray{i},[indent '\t'])];
        case 'char'
          list = [list labelsArray{i}];
%             fprintf([indent '%s\n'],labelsArray{i});
    end
    
end
end