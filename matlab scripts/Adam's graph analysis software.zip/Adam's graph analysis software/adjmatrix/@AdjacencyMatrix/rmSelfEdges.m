function newMat = rmSelfEdges(obj)
%RMSELFEDGES returns a copy of AdjacencyMatrix obj with self-edges
%removed

A = obj.A;

for i = 1:numel(obj.cells)
    R = obj.cells(i).rowNumber;
    C = obj.cells(i).columnNumber;
    if (R>0 && C>0)
        A(obj.cells(i).rowNumber,obj.cells(i).columnNumber) = 0;
    end
    
end

newMat = AdjacencyMatrix(A,obj.rowLabels,obj.columnLabels);

end

