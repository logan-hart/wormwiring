function [commLabelsLinks commLabelsNodes] = getLinkCommunities(obj,varargin)
%UNTITLED12 Summary of this function goes here
%   Detailed explanation goes here

p = 0;
showCommunities = false;
for i = 1:2:numel(varargin)
    switch varargin{i}
        case 'p'
            p = varargin{i+1};
        case 'showCommunities'
            showCommunities = true;
    end
end

[A labels] = getSquareMatrix(obj);

[linkLabels links] = linkCommunities(A,labels,p);

commLabelsNodes = {};
commLabelsNodes{max(linkLabels)} = [];
% for i = 1:numel(nodeGroups)
%     commLabelsNodes{i} = {labels{nodeGroups{i}}};
% end

% links

commLabelsLinks{max(linkLabels)} = [];

for i = 1:max(linkLabels)
    idxs = find(linkLabels == i);
    %         idxs
    for j = 1:(numel(idxs))
%         labels{links(idxs(j),1)}
%         labels{links(idxs(j),2)}
        commLabelsLinks{i} = [commLabelsLinks{i} {sprintf('(%s,%s)',labels{links(idxs(j),1)},labels{links(idxs(j),2)})}];
    end
    commLabelsNodes{i} = union(commLabelsNodes{i},{labels{links(idxs,1:2)}});
end


end

