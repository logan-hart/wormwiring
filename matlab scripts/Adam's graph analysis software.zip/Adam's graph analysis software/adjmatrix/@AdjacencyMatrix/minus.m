function diffMat = minus(mat1, mat2)
%MINUS over load '-' operator to provide adjacency matrix subtraction

% multiply mat2 by -1
minusMat = times(-1,mat2);
diffMat = plus(mat1,minusMat);

end

