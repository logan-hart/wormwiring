% still in development!!

function A = subsasgn(A,S,B)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

switch S.type
    case '()'
        if numel(S.subs) ~= 2, error('subsetting AdjacencyMatrix requires two arguments'),end
        if ~(ischar(S.subs{1}) && ischar(S.subs{2}))
            error('AdjacencyMatrix object must be subsetted using neuron names, or '':''')
        end
        
        switch S.subs{1}
            case ':'
                % In this case we would like to alter an entire column of
                % the matrix, or add an entire column to the matrix
        end
        
    case '.'
        switch S.subs
            case 'matrixType'
                A.matrixType = B;
            
        end
    otherwise
        error('AdjacencyMatrix:SubsetAssign','Operation not recognized');
end

                
end

