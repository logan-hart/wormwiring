function groups = getMuscleGroups()
% GETMUSCLEGROUPS Returns a cell array containing labels of muscle groups
% alternating with their contents

groups{1} = 'dBWM';
groups{2} = {'dBWML21','dBWMR21','dBWML22','dBWMR22','dBWML23',...
    'dBWMR23','dBWML24','dBWMR24'};
groups{3} = 'vBWM';
groups{4} = {'vBWML17','vBWMR18','vBWML19',...
    'vBWMR19','vBWML20','vBWMR20','vBWML21','vBWMR21','vBWML22',...
    'vBWMR22','vBWML23','vBWMR23','vBWMR24'};
groups{5} = 'cdlL/polL/pilL';
groups{6} = {'cdlL','polL','pilL'};
groups{7} = 'cdlR/polR/pilR';
groups{8} = {'cdlR','polR','pilR'};
groups{9} = 'dgl';
groups{10} = {'dglR8','dglL7','dglR7','dglL6','dglR6','dglL5',...
    'dglR5','dglL4','dglR4','dglL3','dglR3','dglL2','dglR2',...
    'dglL1','dglR1'};
groups{11} = 'gec/grt/ob';
groups{12} = {'gecL','gecR','aobL','aobR','pobL','pobR','grtL','grtR'};
groups{13} = 'adp/sp/sr';
groups{14} = {'adp','dspL','dspR','dsrL','dsrR','vspL','vspR','vsrL','vsrR'};
groups{15} = 'ail';
groups{16} = {'ailL','ailR'};
groups{17} = 'int';
groups{18} = {'intL','intR'};

% groups{19} = 'sph',...
%     'gonad','hyp'};



end

