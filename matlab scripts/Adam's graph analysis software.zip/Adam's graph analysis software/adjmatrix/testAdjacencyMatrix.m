A = sparse(12,12);

A(1,2) = 5;
A(2,3) = 30;
A(3,4) = 10;
A(2,4) = 15;
A(4,2) = 5;
A(4,5) = 20;
A(4,6) = 40;
A(6,5) = 10;
A(1,7) = 10;
A(7,1) = 1;
A(1,8) = 15;
A(8,7) = 6;
A(7,9) = 20;
A(9,10) = 40;
A(9,11) = 30;
A(9,12) = 20;


labels = {};
for i = 1:12, labels{i} = num2str(i); end

testAdjMat = AdjacencyMatrix(A,labels,labels,'test Matrix');

% fprintf('\nBetweenness Centralities\n');
% [b varargOut] = betweennessCentrality(testAdjMat,12);
% fprintf('\nClustering Coefficient\n'); 
% C = clusteringCoefficient(testAdjMat,'no test');
% fprintf('\n'); 
% components = getConnectedComponents(testAdjMat,'tolerance',10);
% fprintf('Connected components, tolerance 10\n');
% for comp = components
%     comp{1}.cells
% % end
% fprintf('\nDistribution of reciprocal connections\n');
% [P Prand bins] = distrReciprocal(testAdjMat,5,1);

% calculateReciprocity(testAdjMat);
% charPathLength(testAdjMat,'tolerance',1)
% makeCommunitiesCSV(testAdjMat,'testMatComms.csv');
% fprintf('Recurrency probability, fraction = 1/3: %.3f\n',recurrenceProb(testAdjMat,1/3));
% redMat = combineCells(testAdjMat,{'9,10,11,12',{'9','10','11','12'},'4,5,6',{'4','5','6'}},{});
% showConnections(redMat)
% M = tripletMotifs(testAdjMat,'tolerance',1)
% disp(AdjacencyMatrix.countDoublets(A));
% doubletFrequency(testAdjMat,'tolerance',1,'moduleAnalysis', true);
% N = (sum(sum((A>0) | (A'>0))))/2
% fprintf('\nCommunity Structure by Simulated Annealing\n');
[commLabels Q] = getCommunitiesMMSA(testAdjMat);
% fprintf('\n\nCommunity Structure by Newman\n');
% [matrices Q] = getCommunitiesMM(testAdjMat);

% 
% disp(AdjacencyMatrix.countDoublets(A));
% A2 = rand_doubletcons_bin(A,20)
% disp(AdjacencyMatrix.countDoublets(A2));
% t = AdjacencyMatrix(A2, labels, labels,'randomly rewired matrix');
% showConnections(t);

% [commLabels links nodeGroups] = linkCommunities(A,labels,0);

clear A labels i testAdjMat M