N = 20;
A = zeros(N,20);
for i = 1:19
    A(i,i+1) = 10;
end
for i = 1:18
        A(i,i+2) = 5;
end
for i = 1:17
    A(i,i+3) = 1;
end

% Add some noise
M = 10;
for i = 1:M
    A(randi(N,1),randi(N,1)) = 1;
end


labels = {};
for i = 1:20
    labels{i,1} = sprintf('%u',i);
end



p = randperm(20);

newA = A(p,p);
labels = labels(p);
test = AdjacencyMatrix(newA,labels,labels');

[reorderedA reorderedlabels] = sequentialLayout(test);



image(reorderedA);
