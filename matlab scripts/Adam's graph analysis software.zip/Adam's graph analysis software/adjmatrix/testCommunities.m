% A = sparse(11,11);
% A(1,2) = 1;
% A(2,3) = 1;
% A(2,6) = 1;
% A(6,3) = 1;
% A(6,5) = 1;
% A(1,8) = 1;
% A(7,8) = 1;
% A(8,9) = 1;
% A(7,9) = 1;
% A(9,10) = 1;
% A = A + A';
% A(5,3) = 1;
% A(3,4) = 1;
% A(5,4) = 1;
% A(10,7) = 1;
% A(7,11) = 1;
% A(10,11) = 1;

A  = sparse(7,7);
A(1,2) = 1;
A(1,5) = 1;
A(2,3) = 1;
A(3,4) = 1;
A(4,2) = 1;
A(5,6) = 1;
A(6,7) = 1;
A(7,5) = 1;

labels = {};
for i = 1:11, labels{i} = num2str(i); end

testAdjMat = AdjacencyMatrix(A,labels,labels,'test Matrix');
fprintf('Community Structure\n');
[matrices Q] = getCommunitiesMM(testAdjMat);